<?php
require '../../includes/connect.php';

require '../includes/playerdata.php';

$zoneget = $_GET['zonetarget'];
$zoneget = stripslashes($zoneget);
$zoneget = mysql_real_escape_string($zoneget);

$getmissions = mysql_query("SELECT * FROM zonemissions WHERE battlezone = '$zoneget' AND allegiance='$allegiance'") or die(mysql_error());
$missionoptions = mysql_fetch_array($getmissions);
$missions = array();

switch($allegiance)
{
	case 'authority':
	$permission = 'authdeploy';
	break;
	case 'mercantile':
	$permission = 'mercdeploy';
	break;
	case 'solidarity':
	$permission = 'soldeploy';
	break;
}
$getzoneinfo = mysql_query("SELECT * FROM battlezones WHERE zoneid='$zoneget'");
$zonerows = mysql_fetch_array($getzoneinfo);
$deploypermission = $zonerows[$permission];

if($deploypermission != 0)
{
//Select Missions
echo '<form id="missionform" action="">
	<select id="missionchoice">';
for($count = 0; $count < 5; $count++)
{
	if($count == 0)
	{
		$missionget = 'mission';
	}
	else
	{
		$missionnumber = $count+1;
		$missionget = 'mission'.$missionnumber;
	}
	$missionselect = $missionoptions[$missionget];
	
	$getmissiondetails = mysql_query("SELECT * FROM missions WHERE id='$missionselect'") or die(mysql_error());
	$missionarray = mysql_fetch_array($getmissiondetails);

	$missions[$count][0] = $missionarray['missiontype'];
	$missions[$count][1] = $missionarray['troop'];
	$missions[$count][2] = $missionarray['trooptier'];
	$missions[$count][3] = $missionarray['troopamount'];
	$missions[$count][4] = $missionarray['troop2'];
	$missions[$count][5] = $missionarray['troop2tier'];
	$missions[$count][6] = $missionarray['troop2amount'];
	$missions[$count][7] = $missionarray['troop3'];
	$missions[$count][8] = $missionarray['troop3tier'];
	$missions[$count][9] = $missionarray['troop3amount'];
	$missions[$count][10] = $missionarray['resourcerequire'];
	$missions[$count][11] = $missionarray['resourceamount'];
	
	if($missionarray['missiontype'] == 'killtroops')
	{
		$missiontext = 'Commit your soldiers to a full frontal assault on enemy firebases and positions.';
		$missiontitle = 'Siege Enemy Holdings';
	}
	elseif($missionarray['missiontype'] == 'assassin')
	{
		$missiontext = 'Assassinate a leading figure in your opponent\'s chain of command, stranding their units on the surface.';
		$missiontitle = 'Assassinate General';
	}
	elseif($missionarray['missiontype'] == 'sabotageammo')
	{
		$missiontext = 'Saboteur Units will plant explosives to eliminate enemy supply dumps, severly weakening the effectiveness of their forces.';
		$missiontitle = 'Attack Supply Depots';
	}
	elseif($missionarray['missiontype'] == 'reconbasic')
	{
		$missiontext = 'Recon units will scout out the enemy front lines, reporting back with enemy movements and concentrations to better co-ordinate your own forces.';
		$missiontitle = 'Reconnaissance';
	}
	elseif($missionarray['missiontype'] == 'supportbasic')
	{
		$missiontext = 'Support Units work to establish medical encampments to tend to wounded soldiers, increasing the effectiveness of your forces.';
		$missiontitle = 'Establish Medical Centres';
		if($allegiance == 'authority')
		{
			$missiontext = 'Support Units work to establish repair bays, allowing Drones to be tended to in the midst of engagements, increasing the effectiveness of your forces.';
			$missiontitle = 'Establish Repair Bays';
		}
	}
	
	echo'<option value="'.$count.'">'.$missiontitle.'</option>';
}
echo '</select></form>';
for($count2 = 0; $count2 < 5; $count2++)
{
	$missiontype = $missions[$count2][0];
	$troop = $missions[$count2][1];
	$trooptier = $missions[$count2][2];
	$troopamount = $missions[$count2][3];
	$troop2 = $missions[$count2][4];
	$troop2tier = $missions[$count2][5];
	$troop2amount = $missions[$count2][6];
	$troop3 = $missions[$count2][7];
	$troop3tier = $missions[$count2][8];
	$troop3amount = $missions[$count2][9];
	$resource = $missions[$count2][10];
	$resourceamount = $missions[$count2][11];
	
	$missioncategory = 'blank';
	
	//Check the Mission Type
	if($missiontype == 'killtroops')
	{
		$missiontext = 'Commit your soldiers to a full frontal assault on enemy firebases and positions.';
		$missiontitle = 'Siege Enemy Holdings';
		$missioncategory = 'normal';
	}
	elseif($missiontype == 'assassin')
	{
		$missiontext = 'Assassinate a leading figure in your opponent\'s chain of command, stranding their units on the surface.';
		$missiontitle = 'Assassinate General';
		$missioncategory = 'normal';
	}
	elseif($missiontype == 'sabotageammo')
	{
		$missiontext = 'Saboteur Units will plant explosives to eliminate enemy supply dumps, severly weakening the effectiveness of their forces.';
		$missiontitle = 'Attack Supply Depots';
		$missioncategory = 'normal';
	}
	elseif($missiontype == 'reconbasic')
	{
		$missiontext = 'Recon units will scout out the enemy front lines, reporting back with enemy movements and concentrations to better co-ordinate your own forces.';
		$missiontitle = 'Frontline Reconnaissance';
		$missioncategory = 'normal';
	}
	elseif($missiontype == 'supportbasic')
	{
		$missiontext = 'Support Units work to establish medical encampments to tend to wounded soldiers, increasing the effectiveness of your forces.';
		$missiontitle = 'Establish Medical Centres';
		if($allegiance == 'authority')
		{
			$missiontext = 'Support Units work to establish repair bays, allowing Drones to be tended to in the midst of engagements, increasing the effectiveness of your forces.';
			$missiontitle = 'Establish Repair Bays';
		}
		$missioncategory = 'normal';
	}
	
	switch($troop)
	{
		case 'elite':
		$troopneed = 'Elite Infantry';
		break;
		case 'assassin':
		$troopneed = 'Assassin';
		break;
		case 'support':
		$troopneed = 'Support Unit';
		break;
		case 'recon':
		$troopneed = 'Reconnaissance Patrol';
		break;
		case 'sabotage':
		$troopneed = 'Saboteur';
		break;
		
	}
	
	//Handle Uniques.
	if($missioncategory == 'unique')
	{	
		if($troop2 != 'none')
		{
			switch($troop2)
			{
				case 'elite':
				$troop2need = 'Elite Infantry';
				break;
				case 'assassin':
				$troop2need = 'Assassin';
				break;
				case 'support':
				$troop2need = 'Support Unit';
				break;
				case 'recon':
				$troop2need = 'Reconnaissance Patrol';
				break;
				case 'sabotage':
				$troop2need = 'Saboteur';
				break;
			}
		}
		else
		{
			$troop2need = ' ';
			$troop2amount = ' ';
			$troop2tier = ' ';
		}
		if($troop3 != 'none')
		{
			switch($troop3)
			{
				case 'elite':
				$troop3need = 'Elite Infantry';
				break;
				case 'assassin':
				$troop3need = 'Assassin';
				break;
				case 'support':
				$troop3need = 'Support Unit';
				break;
				case 'recon':
				$troop3need = 'Reconnaissance Patrol';
				break;
				case 'sabotage':
				$troop3need = 'Saboteur';
				break;
			}
		}
		else
		{
			$troop3need = ' ';
			$troop3amount = ' ';
			$troop3tier = ' ';
		}
		//Check if resources are needed.
		if($resource != 'none')
		{
	
		}
		echo '<span class="missioninfo" id="mission'.$count2.'"><h3>'.$missiontitle.'</h3><strong>'.$missiontext.'</strong><br>
		<b>Requires: </b>'.$troopamount.' '.$troopneed;
		if($troop2 !='none'){ echo', '.$troop2amount.' '.$troop2need;}
		if($troop3 != 'none'){echo', '.$troop3amount.' '.$troop3need;}
		//Get Active Missions
		$missiondetails = mysql_query("SELECT * FROM missions WHERE allegiance='$allegiance' AND missiontype='$missiontype'");
		$missioninfo = mysql_fetch_array($missiondetails);
		$getactives = mysql_query("SELECT * FROM activemissions WHERE user='$username' AND colony='$chosencolony' AND battlezone='$zoneget' AND mission='$missioninfo[id]' AND allegiance='authority'");
		$activemissions = mysql_num_rows($getactives);
		if($activemissions == 0)
		{
			echo '<form id="missionform'.$count2.'" action=""></form>
			<br><br></span>';
		}
		else
		{
			$activeinfo = mysql_fetch_array($getactives);
			echo '<br><br><strong>Mission Underway. Time to Completion: </strong>'.$activeinfo['ticks'].' Weeks.';
		}
	}
	elseif($missioncategory == 'normal')
	{
		$getavailablekits = mysql_query("SELECT * FROM recruits WHERE factionuser = '$username' AND colony='$chosencolony' AND type='$troop' AND trainingtime='0'") or die(mysql_error());
		echo '<span class="missioninfo" id="mission'.$count2.'"><h3>'.$missiontitle.'</h3><strong>'.$missiontext.'</strong><br>
		<b>Requires: </b>'.$troopamount.' '.$troopneed;
		//Get Active Missions
		$missiondetails = mysql_query("SELECT * FROM missions WHERE allegiance='$allegiance' AND missiontype='$missiontype'");
		$missioninfo = mysql_fetch_array($missiondetails);
		$getactives = mysql_query("SELECT * FROM activemissions WHERE user='$username' AND colony='$chosencolony' AND battlezone='$zoneget' AND mission='$missioninfo[id]' AND allegiance='authority'");
		$activemissions = mysql_num_rows($getactives);
		if($activemissions == 0)
		{
			if(mysql_num_rows($getavailablekits))
			{
				echo '<span id="missionform'.$count2.'"><form id="missionform'.$count2.'" action="">
				<input type="hidden" name="formmissiontype" value="'.$missiontype.'">
				<input type="hidden" name="formmissionid" value="missionid'.$count2.'">
				<input type="hidden" name="formmissionzone" value="'.$zoneget.'">
				<select name="formmissiontroops">';
				while($availabletroops = mysql_fetch_array($getavailablekits))
				{
					echo '<option value="'.$availabletroops['id'].'">'.$troopneed.' | Skill: '.$availabletroops['skill'].', Tier: '.$availabletroops['tier'].'</option>';
				}
		
				echo '</select>
				<input type="submit" class="specButton" id="specButton'.$count2.' "value="Dispatch"></form></span>';
			}
			else
			{
				echo '<br>No available units to dispatch.';
			}
			
		}
		else
		{
			$activeinfo = mysql_fetch_array($getactives);
			echo '<br><br><strong>Mission Underway. Time to Completion: </strong>'.$activeinfo['ticksleft'].' Weeks.';
		}
		echo '<br><br></span>';
	}
}
}
else
{
	echo '<center><strong>You cannot deploy Special Forces here.</strong></center>';
}

?>