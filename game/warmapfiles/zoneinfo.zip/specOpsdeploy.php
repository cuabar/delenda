<?php
require '../../includes/connect.php';

require '../includes/playerdata.php';

$missiontype = $_POST['formmissiontype'];
$missionid = $_POST['formmissionid'];
$battlezone = $_POST['formmissionzone'];
$troopid = $_POST['formmissiontroops'];

$missiontype=stripslashes($missiontype);
$missionid = stripslashes($missionid);
$battlezone = stripslashes($battlezone);
$troopid = stripslashes($troopid);

$missiontype = mysql_real_escape_string($missiontype);
$missionid = mysql_real_escape_string($missionid);
$battlezone = mysql_real_escape_string($battlezone);
$troopid = mysql_real_escape_string($troopid);

//Get the mission information.
$missiondetails = mysql_query("SELECT * FROM missions WHERE allegiance='$allegiance' AND missiontype='$missiontype'");
$missioninfo = mysql_fetch_array($missiondetails);
//Get the Troop Info
$troopdetails = mysql_query("SELECT * FROM recruits WHERE id='$troopid'");
$troopinfo = mysql_fetch_array($troopdetails);
//Place the mission into the "Active Missions" table
$missionrecord = mysql_query("INSERT INTO activemissions(user,colony,allegiance,battlezone,mission,tier,skill,ticksleft) VALUES('$username','$chosencolony','$allegiance','$battlezone','$missioninfo[id]','$troopinfo[tier]','$troopinfo[skill]','$missioninfo[ticks]')") or die(mysql_error());
//Remove troop
$troopassign = mysql_query("DELETE FROM recruits WHERE id='$troopid'");

echo '<br><br><strong>Mission Underway. Time to Completion: </strong>'.$missioninfo['ticks'].' Weeks.';
?>